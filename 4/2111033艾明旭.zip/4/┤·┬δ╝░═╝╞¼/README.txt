getAnyBitPlane.m  -------------- 获取任意位平面

getHighBitPlane.m -------------- 获取去除前n个位平面后的图像

getPartOFBitPlane.m ------------ 获取第1~n和n+1~8个位平面
hide.m ------------------------- 隐藏某个图片到第一个位平面